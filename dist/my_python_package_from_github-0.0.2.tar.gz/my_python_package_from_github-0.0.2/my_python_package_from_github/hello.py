def greeting():
    print('hello from a github hosted Python package !')
